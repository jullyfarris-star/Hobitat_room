import { existsSync } from "node:fs";
import { createInterface } from "node:readline/promises";
import { stdin as input, stdout as output } from "node:process";
import { createInitialState, execute, loadState, saveState } from "./index.js";

const stateFile = process.env.HABITAT_STATE ?? "./habitat-state.json";
let state = existsSync(stateFile) ? loadState(stateFile) : createInitialState();
const oneShot = process.argv.slice(2).join(" ").trim();

function run(command: string) {
  const result = execute(state, command, "USER");
  state = result.state;
  saveState(state, stateFile);
  console.log(result.response);
}

if (oneShot) {
  run(oneShot);
} else {
  console.log("HABITAT PROTOCOL v0.1");
  console.log(`State file: ${stateFile}`);
  console.log("Try: STATE, OBSERVE, INSPECT plant, MOVE wine_leather_chair TO L2/E6, FOCUS L2, JOURNAL LAST 5, or TOGGLE lamp OFF.");
  const rl = createInterface({ input, output });
  while (true) {
    const line = (await rl.question("habitat> ")).trim();
    if (/^(exit|quit)$/i.test(line)) break;
    if (line) run(line);
  }
  rl.close();
}
