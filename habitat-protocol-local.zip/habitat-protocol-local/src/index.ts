import * as fs from "node:fs";

export type Level = "L1" | "L2";
export type Focus = "ALL" | Level;
export type Actor = "AI" | "USER" | "SYSTEM";
export type Result = "accepted" | "rejected" | "observed";

export type HabitatObject = {
  id: string;
  name: string;
  type: string;
  level: Level;
  location: string;
  material: string;
  surface?: string;
  color: string;
  dimensions?: { width: number; depth: number; height: number };
  movable: boolean;
  capabilities: string[];
  state: string;
};

export type JournalEvent = {
  eventId: string;
  timestamp: string;
  actor: Actor;
  action: string;
  target?: string;
  from?: string;
  to?: string;
  result: Result;
  reason: string;
};

export type WorldState = {
  version: 1;
  habitatId: string;
  activeLevel: Focus;
  objects: Record<string, HabitatObject>;
  avatarState: { level: Level; location: string; activity: string };
  environment: { lampL1: boolean; windowLight: number; visibleWalls: string[] };
  spatialMemory: Record<string, string>;
  objectMemory: Record<string, string[]>;
  journal: JournalEvent[];
  timeline: string[];
};

export type Command =
  | { action: "OBSERVE" }
  | { action: "INSPECT"; objectRef: string }
  | { action: "MOVE"; objectRef: string; level?: Level | undefined; cell: string }
  | { action: "FOCUS"; level: Focus }
  | { action: "TOGGLE"; objectRef: string; value: "ON" | "OFF" }
  | { action: "JOURNAL"; count: number }
  | { action: "STATE" };

export type CommandResult = { state: WorldState; response: string; event: JournalEvent };

const CELL = /^[A-J](?:10|[1-9])$/;
const stamp = () => new Date().toISOString();
const makeEvent = (actor: Actor, action: string, reason: string, result: Result, extras: Partial<JournalEvent> = {}): JournalEvent => ({ eventId: `${Date.now()}-${Math.random().toString(16).slice(2)}`, timestamp: stamp(), actor, action, reason, result, ...extras });
const addEvent = (state: WorldState, entry: JournalEvent): WorldState => ({ ...state, journal: [entry, ...state.journal].slice(0, 100), timeline: [...state.timeline, entry.eventId] });
const copyState = (state: WorldState): WorldState => structuredClone(state);

export function createInitialState(): WorldState {
  const objects: HabitatObject[] = [
    { id: "lab", name: "Lab", type: "workspace", level: "L1", location: "B6", material: "steel + glass", color: "steel blue", movable: false, capabilities: ["inspect", "work"], state: "active" },
    { id: "desk", name: "Desk", type: "furniture", level: "L1", location: "C6", material: "oak + steel", color: "timber", movable: true, capabilities: ["inspect", "move", "work"], state: "available" },
    { id: "tool_station", name: "Tool station", type: "utility", level: "L1", location: "D8", material: "painted steel", color: "oxide", movable: true, capabilities: ["inspect", "move", "store"], state: "available" },
    { id: "sofa", name: "Sofa", type: "furniture", level: "L1", location: "H7", material: "wine textile", color: "wine", movable: false, capabilities: ["inspect", "sit"], state: "available" },
    { id: "stairs", name: "Stairs", type: "structure", level: "L1", location: "F5", material: "steel + oak", color: "graphite", movable: false, capabilities: ["inspect", "climb"], state: "fixed" },
    { id: "lamp", name: "Lamp", type: "lighting", level: "L1", location: "B3", material: "brass + glass", color: "amber", movable: true, capabilities: ["inspect", "move", "toggle"], state: "on" },
    { id: "wine_leather_chair", name: "Wine leather chair", type: "furniture", level: "L2", location: "C6", material: "leather", surface: "matte", color: "wine", dimensions: { width: 0.8, depth: 0.8, height: 0.9 }, movable: true, capabilities: ["inspect", "move", "sit"], state: "available" },
    { id: "velvet_pillow", name: "Velvet pillow", type: "soft object", level: "L2", location: "D6", material: "velvet", surface: "soft", color: "steel blue", movable: true, capabilities: ["inspect", "move"], state: "available" },
    { id: "plant", name: "Plant", type: "living object", level: "L2", location: "E2", material: "ceramic + leaf", surface: "matte", color: "plant green", movable: true, capabilities: ["inspect", "move", "water"], state: "alive" },
    { id: "shelf", name: "Shelf", type: "storage", level: "L2", location: "I4", material: "oak", color: "timber", movable: false, capabilities: ["inspect", "store"], state: "fixed" },
  ];
  return { version: 1, habitatId: "habitat-v0.1", activeLevel: "ALL", objects: Object.fromEntries(objects.map((item) => [item.id, item])), avatarState: { level: "L1", location: "C4", activity: "observing" }, environment: { lampL1: true, windowLight: 0.7, visibleWalls: ["back", "side"] }, spatialMemory: Object.fromEntries(objects.map((item) => [item.id, `${item.level}/${item.location}`])), objectMemory: Object.fromEntries(objects.map((item) => [item.id, []])), journal: [], timeline: [] };
}

export function parseCommand(input: string): Command | null {
  const text = input.trim();
  if (/^OBSERVE$/i.test(text)) return { action: "OBSERVE" };
  const inspect = text.match(/^INSPECT\s+(.+)$/i); if (inspect) return { action: "INSPECT", objectRef: inspect[1]!.trim() };
  const move = text.match(/^MOVE\s+(.+?)\s+(?:TO\s+)?(?:(L1|L2)\s*\/\s*)?([A-J](?:10|[1-9]))$/i); if (move) return { action: "MOVE", objectRef: move[1]!.trim(), level: move[2]?.toUpperCase() as Level | undefined, cell: move[3]!.toUpperCase() };
  const focus = text.match(/^(?:FOCUS|SHOW)\s+(L1|L2|ALL)$/i); if (focus) return { action: "FOCUS", level: focus[1]!.toUpperCase() as Focus };
  const toggle = text.match(/^TOGGLE\s+(.+?)\s+(ON|OFF)$/i); if (toggle) return { action: "TOGGLE", objectRef: toggle[1]!.trim(), value: toggle[2]!.toUpperCase() as "ON" | "OFF" };
  const journal = text.match(/^JOURNAL(?:\s+LAST\s+(\d+))?$/i); if (journal) return { action: "JOURNAL", count: Number(journal[1] ?? 5) };
  if (/^STATE(?:\s+SUMMARY)?$/i.test(text)) return { action: "STATE" };
  return null;
}

function findObject(state: WorldState, ref: string): HabitatObject | undefined { return Object.values(state.objects).find((item) => item.id.toLowerCase() === ref.toLowerCase() || item.name.toLowerCase() === ref.toLowerCase()); }
export function validateMove(state: WorldState, objectId: string, level: Level, cell: string): string | null { const item = state.objects[objectId]; if (!item) return "object does not exist"; if (!item.movable) return "object is fixed in place"; if (!CELL.test(cell)) return "invalid cell; expected A–J × 1–10"; if (item.level !== level) return `cross-level move rejected; object belongs to ${item.level}`; if (Object.values(state.objects).some((other) => other.id !== objectId && other.level === level && other.location === cell)) return "target cell is occupied"; return null; }

export function execute(state: WorldState, input: string, actor: Actor = "AI"): CommandResult {
  const command = parseCommand(input);
  if (!command) { const entry = makeEvent(actor, "COMMAND", "unsupported syntax", "rejected"); return { state: addEvent(copyState(state), entry), response: "Unsupported command. Use OBSERVE, INSPECT, MOVE, FOCUS, TOGGLE, JOURNAL, or STATE.", event: entry }; }
  if (command.action === "OBSERVE") { const entry = makeEvent(actor, "OBSERVE", `${Object.keys(state.objects).length} objects across L1/L2`, "observed"); return { state: addEvent(copyState(state), entry), response: `${entry.reason}. Active focus: ${state.activeLevel}.`, event: entry }; }
  if (command.action === "STATE") { const entry = makeEvent(actor, "STATE", "World State inspected without mutation", "observed"); const view = { ...state, journal: state.journal.slice(0, 10) }; return { state: addEvent(copyState(state), entry), response: JSON.stringify(view, null, 2), event: entry }; }
  if (command.action === "JOURNAL") { const entry = makeEvent(actor, "JOURNAL", `returned last ${command.count} events`, "observed"); const response = state.journal.slice(0, command.count).map((item) => `${item.timestamp} ${item.result} ${item.action}: ${item.reason}`).join("\n") || "Journal is empty."; return { state: addEvent(copyState(state), entry), response, event: entry }; }
  if (command.action === "FOCUS") { const entry = makeEvent(actor, "FOCUS", `focus changed to ${command.level}`, "accepted"); return { state: addEvent({ ...copyState(state), activeLevel: command.level }, entry), response: `Focus: ${command.level}.`, event: entry }; }
  const item = findObject(state, command.objectRef);
  if (!item) { const entry = makeEvent(actor, command.action, `object not found: ${command.objectRef}`, "rejected", { target: command.objectRef }); return { state: addEvent(copyState(state), entry), response: entry.reason, event: entry }; }
  if (command.action === "INSPECT") { const entry = makeEvent(actor, "INSPECT", `${item.name} at ${item.level}/${item.location}`, "observed", { target: item.id }); const next = copyState(state); next.objectMemory[item.id] = [...(next.objectMemory[item.id] ?? []), entry.eventId]; return { state: addEvent({ ...next, }, entry), response: JSON.stringify(item, null, 2), event: entry }; }
  if (command.action === "TOGGLE") { if (!item.capabilities.includes("toggle")) { const entry = makeEvent(actor, "TOGGLE", `${item.name} does not support toggle`, "rejected", { target: item.id }); return { state: addEvent(copyState(state), entry), response: entry.reason, event: entry }; } const next = copyState(state); next.environment.lampL1 = command.value === "ON"; next.objects[item.id] = { ...item, state: command.value === "ON" ? "on" : "off" }; const entry = makeEvent(actor, "TOGGLE", `${item.name} set to ${command.value}`, "accepted", { target: item.id }); return { state: addEvent(next, entry), response: entry.reason, event: entry }; }
  const level = command.level ?? item.level; const error = validateMove(state, item.id, level, command.cell); if (error) { const entry = makeEvent(actor, "MOVE", error, "rejected", { target: item.id, to: `${level}/${command.cell}` }); return { state: addEvent(copyState(state), entry), response: `Move rejected: ${error}.`, event: entry }; } const next = copyState(state); const from = `${item.level}/${item.location}`; next.objects[item.id] = { ...item, location: command.cell }; next.spatialMemory[item.id] = `${level}/${command.cell}`; const entry = makeEvent(actor, "MOVE", `${item.name} moved`, "accepted", { target: item.id, from, to: `${level}/${command.cell}` }); return { state: addEvent(next, entry), response: `Move accepted: ${from} → ${level}/${command.cell}.`, event: entry };
}

export function saveState(state: WorldState, filePath: string): void { fs.writeFileSync(filePath, JSON.stringify(state, null, 2), "utf8"); }
export function loadState(filePath: string, fallback = createInitialState()): WorldState { try { return JSON.parse(fs.readFileSync(filePath, "utf8")) as WorldState; } catch { return fallback; } }
