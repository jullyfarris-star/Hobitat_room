import { afterEach, describe, expect, it } from "vitest";
import { existsSync, mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createInitialState, execute, loadState, parseCommand, saveState } from "../src/index.js";

let directory = "";
afterEach(() => { if (directory && existsSync(directory)) rmSync(directory, { recursive: true, force: true }); });

describe("HABITAT protocol", () => {
  it("parses the complete command family", () => {
    expect(parseCommand("OBSERVE")?.action).toBe("OBSERVE");
    expect(parseCommand("INSPECT plant")?.action).toBe("INSPECT");
    expect(parseCommand("MOVE wine_leather_chair TO L2/E6")?.action).toBe("MOVE");
    expect(parseCommand("FOCUS L2")?.action).toBe("FOCUS");
    expect(parseCommand("TOGGLE lamp OFF")?.action).toBe("TOGGLE");
    expect(parseCommand("JOURNAL LAST 4")?.action).toBe("JOURNAL");
    expect(parseCommand("STATE")?.action).toBe("STATE");
  });

  it("accepts a valid move and updates spatial memory and Journal", () => {
    const result = execute(createInitialState(), "MOVE wine_leather_chair TO L2/E6", "USER");
    expect(result.event.result).toBe("accepted");
    expect(result.state.objects.wine_leather_chair!.location).toBe("E6");
    expect(result.state.spatialMemory.wine_leather_chair).toBe("L2/E6");
    expect(result.state.journal[0]?.action).toBe("MOVE");
  });

  it("rejects an occupied target without mutating the object", () => {
    const result = execute(createInitialState(), "MOVE wine_leather_chair TO L2/D6", "USER");
    expect(result.event.result).toBe("rejected");
    expect(result.state.objects.wine_leather_chair!.location).toBe("C6");
    expect(result.response).toContain("occupied");
  });

  it("rejects fixed objects and invalid cells", () => {
    const fixed = execute(createInitialState(), "MOVE shelf TO L2/E4");
    const invalid = execute(createInitialState(), "MOVE plant TO L2/Z99");
    expect(fixed.event.result).toBe("rejected");
    expect(invalid.event.result).toBe("rejected");
  });

  it("supports focus, inspection, toggle, observe, and journal", () => {
    let state = createInitialState();
    state = execute(state, "FOCUS L2").state;
    state = execute(state, "INSPECT plant").state;
    state = execute(state, "TOGGLE lamp OFF").state;
    expect(state.activeLevel).toBe("L2");
    expect(state.environment.lampL1).toBe(false);
    const observed = execute(state, "OBSERVE");
    expect(observed.event.result).toBe("observed");
    state = observed.state;
    expect(execute(state, "JOURNAL LAST 2").response).toContain("OBSERVE");
  });

  it("round-trips JSON persistence", () => {
    directory = mkdtempSync(join(tmpdir(), "habitat-") );
    const file = join(directory, "state.json");
    const state = execute(createInitialState(), "MOVE plant TO L2/E3").state;
    saveState(state, file);
    const restored = loadState(file);
    expect(restored.objects.plant!.location).toBe("E3");
    expect(restored.journal.length).toBe(1);
  });
});
